#!/usr/bin/env python3
"""CSV-backed habit tracker CLI with timestamped completions (Python 3.7+).

Run: python habit_tracker.py
Run tests: python -m unittest discover -s tests -v
The five example habits can be loaded through menu option 7.
"""
import csv
import os
import sys
import tempfile
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, time
from pathlib import Path

from analytics import (all_habits, habits_by_frequency, longest_streak_all_habits,
                       longest_streak_for_habit, current_streak)

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / 'habits.csv'
FIXTURE_FILE = BASE_DIR / 'fixtures' / 'habit_fixture.csv'
FIELDS = ['id', 'title', 'description', 'frequency', 'created_at', 'completions']


def parse_timestamp(value):
    """Convert a datetime, date or ISO timestamp to a datetime."""
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime.combine(value, time.min)
    raw = str(value).strip()
    try:
        return datetime.fromisoformat(raw)
    except ValueError:
        raise ValueError('Invalid completion timestamp: {}'.format(raw))


@dataclass
class Habit:
    """A daily/weekly habit with creation date and dated completion timestamps."""
    title: str
    description: str
    frequency: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: date = field(default_factory=date.today)
    completions: list = field(default_factory=list)

    def __post_init__(self):
        """Validate fields and normalize completion timestamps."""
        self.title = self.title.strip()
        self.description = self.description.strip()
        self.frequency = self.frequency.strip().lower()
        if not self.title:
            raise ValueError('Habit title cannot be empty.')
        if self.frequency not in ('daily', 'weekly'):
            raise ValueError('Frequency must be daily or weekly.')
        if isinstance(self.created_at, str):
            self.created_at = date.fromisoformat(self.created_at)
        parsed = sorted(parse_timestamp(item) for item in self.completions)
        # One completion per calendar day for daily habits, or per ISO week for weekly.
        unique = {}
        for timestamp in parsed:
            unique[self._period_key(timestamp)] = timestamp
        self.completions = sorted(unique.values())

    def _period_key(self, timestamp):
        """Identify the daily date or ISO year/week represented by a timestamp."""
        day = timestamp.date()
        if self.frequency == 'daily':
            return day
        iso = day.isocalendar()
        return iso[0], iso[1]

    def complete(self, when=None):
        """Record a timestamp; return False if this period is already completed."""
        timestamp = parse_timestamp(when) if when is not None else datetime.now()
        if any(self._period_key(existing) == self._period_key(timestamp)
               for existing in self.completions):
            return False
        self.completions.append(timestamp)
        self.completions.sort()
        return True


class HabitRepository:
    """Load and atomically save habit records in a local CSV file."""
    def __init__(self, path=DATA_FILE):
        self.path = Path(path)

    def load(self):
        """Load all saved habits; return [] if the file does not exist."""
        if not self.path.exists():
            return []
        habits = []
        try:
            with self.path.open('r', newline='', encoding='utf-8') as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames or not set(FIELDS).issubset(reader.fieldnames):
                    raise ValueError('CSV is missing required columns.')
                for line_number, row in enumerate(reader, 2):
                    try:
                        raw = row.get('completions') or ''
                        habits.append(Habit(
                            id=row['id'], title=row['title'],
                            description=row.get('description') or '',
                            frequency=row['frequency'], created_at=row['created_at'],
                            completions=[part for part in raw.split(';') if part]
                        ))
                    except (ValueError, KeyError, TypeError, AttributeError) as exc:
                        raise ValueError('Invalid CSV row {}: {}'.format(line_number, exc))
        except (csv.Error, UnicodeError) as exc:
            raise ValueError('Could not read CSV: {}'.format(exc))
        return habits

    def save(self, habits):
        """Persist all habits using an atomic file replacement."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix='.habits-', suffix='.tmp', dir=str(self.path.parent))
        try:
            with os.fdopen(fd, 'w', newline='', encoding='utf-8') as handle:
                writer = csv.DictWriter(handle, fieldnames=FIELDS)
                writer.writeheader()
                for habit in habits:
                    writer.writerow({
                        'id': habit.id, 'title': habit.title,
                        'description': habit.description, 'frequency': habit.frequency,
                        'created_at': habit.created_at.isoformat(),
                        'completions': ';'.join(t.isoformat(timespec='seconds')
                                                for t in habit.completions)
                    })
            os.replace(temporary, str(self.path))
        except Exception:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise


class HabitService:
    """Coordinate habit operations with CSV persistence."""
    def __init__(self, repository):
        self.repository = repository

    def list_habits(self):
        """Return all persisted habits."""
        return self.repository.load()

    def create(self, title, description, frequency):
        """Create and save a new habit."""
        habit = Habit(title, description, frequency)
        habits = self.list_habits()
        habits.append(habit)
        self.repository.save(habits)
        return habit

    def complete(self, habit_id, when=None):
        """Complete a habit in the specified period and save the timestamp."""
        habits = self.list_habits()
        for habit in habits:
            if habit.id == habit_id:
                if not habit.complete(when):
                    raise ValueError('Already completed for this {}.'.format(
                        'day' if habit.frequency == 'daily' else 'week'))
                self.repository.save(habits)
                return habit
        raise KeyError('Habit not found.')

    def edit(self, habit_id, title, description, frequency):
        """Update a habit, retaining timestamps and rejecting invalid values."""
        habits = self.list_habits()
        for habit in habits:
            if habit.id == habit_id:
                updated = Habit(title, description, frequency, id=habit.id,
                                created_at=habit.created_at,
                                completions=habit.completions)
                habits[habits.index(habit)] = updated
                self.repository.save(habits)
                return updated
        raise KeyError('Habit not found.')

    def delete(self, habit_id):
        """Permanently delete a habit and its completion history."""
        habits = self.list_habits()
        for index, habit in enumerate(habits):
            if habit.id == habit_id:
                removed = habits.pop(index)
                self.repository.save(habits)
                return removed
        raise KeyError('Habit not found.')

    def load_examples(self, fixture_path=FIXTURE_FILE):
        """Import the five example habits only into an empty data file."""
        if self.list_habits():
            raise ValueError('Example import requires an empty habit list.')
        examples = HabitRepository(fixture_path).load()
        if len(examples) != 5:
            raise ValueError('Expected exactly five predefined habits.')
        self.repository.save(examples)
        return examples


class HabitCLI:
    """Interactive text menu for managing and analysing habits."""
    def __init__(self, service):
        self.service = service

    def choose(self, habits, prompt):
        """Prompt the user to select an existing habit by number."""
        for index, habit in enumerate(habits, 1):
            print('{}. {} [{}]'.format(index, habit.title, habit.frequency))
        try:
            choice = int(input('{} (0 to cancel): '.format(prompt)))
            return habits[choice - 1] if 1 <= choice <= len(habits) else None
        except ValueError:
            print('Please enter a valid number.')
            return None

    def view(self):
        """Display tracked habits and their current streaks."""
        habits = self.service.list_habits()
        if not habits:
            print('No habits yet. Create one or load the examples.')
        for habit in habits:
            print('{} [{}] | {} completions | current streak: {}'.format(
                habit.title, habit.frequency, len(habit.completions),
                current_streak(habit)))
            print('  Created: {} | {}'.format(habit.created_at, habit.description))
            if habit.completions:
                print('  Last completed: {}'.format(habit.completions[-1].isoformat(sep=' ', timespec='seconds')))

    def create(self):
        """Prompt for and create a habit."""
        title = input('Habit title: ')
        description = input('Description (optional): ')
        frequency = input('Frequency (daily/weekly): ')
        habit = self.service.create(title, description, frequency)
        print('Created: {}'.format(habit.title))

    def complete(self):
        """Mark the selected habit completed at the current date and time."""
        habit = self.choose(self.service.list_habits(), 'Complete which habit?')
        if habit:
            updated = self.service.complete(habit.id)
            print('Completed {} at {}'.format(updated.title, updated.completions[-1]))

    def edit(self):
        """Edit the selected habit."""
        habit = self.choose(self.service.list_habits(), 'Edit which habit?')
        if habit:
            title = input('Title [{}]: '.format(habit.title)).strip() or habit.title
            description = input('Description [{}]: '.format(habit.description)).strip() or habit.description
            frequency = input('Frequency [{}]: '.format(habit.frequency)).strip() or habit.frequency
            self.service.edit(habit.id, title, description, frequency)
            print('Habit updated.')

    def delete(self):
        """Delete the selected habit after confirmation."""
        habit = self.choose(self.service.list_habits(), 'Delete which habit?')
        if habit and input('Delete {} permanently? (yes/no): '.format(habit.title)).strip().lower() == 'yes':
            self.service.delete(habit.id)
            print('Habit deleted.')

    def analyse(self):
        """Show all four required functional analytics outputs."""
        habits = all_habits(self.service.list_habits())
        print('\nANALYTICS')
        print('All tracked habits: {}'.format(', '.join(h.title for h in habits) or '(none)'))
        for frequency in ('daily', 'weekly'):
            print('{} habits: {}'.format(frequency.title(), ', '.join(
                h.title for h in habits_by_frequency(habits, frequency)) or '(none)'))
        print('Longest historical streak across all habits: {}'.format(longest_streak_all_habits(habits)))
        if habits:
            habit = self.choose(habits, 'View longest streak for which habit?')
            if habit:
                print('Longest streak for {}: {} {}'.format(
                    habit.title, longest_streak_for_habit(habit),
                    'days' if habit.frequency == 'daily' else 'weeks'))

    def run(self):
        """Run the main interactive command-line menu."""
        while True:
            print('\nHABIT TRACKER')
            print('1. View habits\n2. Create habit\n3. Complete habit\n4. Edit habit')
            print('5. Delete habit\n6. Analyse habits\n7. Load five example habits\n8. Exit')
            option = input('Choose 1-8: ').strip()
            if option == '8':
                print('Goodbye!')
                return
            try:
                actions = {'1': self.view, '2': self.create, '3': self.complete,
                           '4': self.edit, '5': self.delete, '6': self.analyse}
                if option in actions:
                    actions[option]()
                elif option == '7':
                    examples = self.service.load_examples()
                    print('Loaded {} example habits with four weeks of data.'.format(len(examples)))
                else:
                    print('Choose a number from 1 to 8.')
            except (ValueError, KeyError, OSError) as exc:
                print('Error: {}'.format(exc))
            except (EOFError, KeyboardInterrupt):
                print('\nGoodbye!')
                return


if __name__ == '__main__':
    HabitCLI(HabitService(HabitRepository())).run()
